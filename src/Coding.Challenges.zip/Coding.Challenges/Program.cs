﻿namespace Coding.Challenges
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This program is used to solve some coding challenges as best that I can");
        }
    }
}